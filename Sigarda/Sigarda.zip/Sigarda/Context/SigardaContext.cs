﻿using System.Data.Entity;
using Sigarda.Models;

namespace Sigarda.Context
{
    public class SigardaContext : DbContext
    {
        public SigardaContext() : base("SigardaDB")
        {
        }

        public DbSet<Tournament> Tournaments { get; set; }
        public DbSet<Branch> Branchs { get; set; }
        public DbSet<User> Users { get; set; }
    }
}