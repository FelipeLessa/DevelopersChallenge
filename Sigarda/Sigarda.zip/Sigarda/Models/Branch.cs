﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Sigarda.Models
{
    public class Branch
    {
        [Key]
        public int BranchId { get; set; }
        public int TournamentId { get; set; }
        public int Round { get; set; }
        public int SortBranch { get; set; }

        [DisplayName("Team Name")]
        public string Team { get; set; }

        [ForeignKey("TournamentId")]
        public virtual Tournament Tournaments { get; set; }
    }
}