﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Sigarda.Models
{
    public class Tournament
    {
        [Key]
        public int TournamentId { get; set; }
        public string Name { get; set; }

        [DisplayName("Total Branch")]
        public int TotalBranch { get; set; }

        public virtual ICollection<Branch> Branchs { get; set; }
    }
}