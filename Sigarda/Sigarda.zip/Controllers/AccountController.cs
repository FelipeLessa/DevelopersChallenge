﻿using Sigarda.Context;
using Sigarda.Models;
using System.Linq;
using System.Web.Mvc;

namespace Sigarda.Controllers
{
    public class AccountController : Controller
    {
        private SigardaContext db = new SigardaContext();

        public ActionResult Index()
        {
            Session.Abandon();

            return View("Login");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login([Bind(Include = "Login,Password")] User user)
        {
            if (ModelState.IsValid)
            {
                var v = db.Users.Where(a => a.Login.Equals(user.Login) && a.Password.Equals(user.Password)).FirstOrDefault();

                if (v != null)
                {
                    Session["userId"] = v.UserId.ToString();
                    Session["userName"] = v.Name.ToString();
                    return RedirectToAction("Index", "Tournament");
                }

            }
            return RedirectToAction("Index");
        }

        public ActionResult AbandonSession()
        {
            Session.Abandon();

            return RedirectToAction("Index", "Tournament");
        }
    }
}
