﻿using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using Sigarda.Context;
using Sigarda.Models;

namespace Sigarda.Controllers
{
    public class BranchController : Controller
    {
        private SigardaContext db = new SigardaContext();

        public ActionResult Update([Bind(Include = "TournamentId,Team,Round,SortBranch")] Branch branch)
        {
            branch.BranchId = 
                (db.Branchs.AsNoTracking().Where(x => x.TournamentId == branch.TournamentId && x.SortBranch == branch.SortBranch && x.Round == branch.Round))
                .First()
                .BranchId;

            if (ModelState.IsValid)
            {
                db.Entry(branch).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("TreeMap/"+ branch.TournamentId, "Tournament");
            }
            return RedirectToAction("TreeMap/" + branch.TournamentId, "Tournament");
        }

        // GET: Branch
        public ActionResult Index(int TournamentId)

        {
            return View(db.Branchs.Include(c => c.Tournaments)
                .ToList()
                .Where(x => x.TournamentId == TournamentId));
        }

        // GET: Branch/Create
        public ActionResult Create(int TournamentId)
        {
            Tournament tournament = (db.Tournaments.Where(x => x.TournamentId == TournamentId)).First();
            int teamAmount = (db.Branchs.Where(x => x.TournamentId == TournamentId)).Count();

            ViewBag.FirstRound = tournament.TotalBranch;
            ViewBag.TeamAmount = teamAmount;

            return View();
        }

        // POST: Branch/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BranchId,TournamentId,Team,Round,SortBranch")] Branch branch)
        {
            Tournament tournament = (db.Tournaments.Where(x => x.TournamentId == branch.TournamentId)).First();

            int totalTeam = tournament.TotalBranch * 2;

            int currentTeam = 0;
                int.TryParse(Request.Form["currentTeam"], out currentTeam);

            branch.SortBranch = currentTeam;

            //If not have more initial teams
            if (totalTeam == currentTeam)
            {
                //Save the last manual team
                db.Branchs.Add(branch);
                db.SaveChanges();

                //We not going start from the first branch
                int Branchs = tournament.TotalBranch / 2;

                //Now we create the remaining empty teams
                while (Branchs != 0)
                {
                    for (var z = 1; z <= (Branchs * 2); z++)
                    {
                        branch.SortBranch = z;
                        branch.Team = "";
                        branch.Round = Branchs;

                        db.Branchs.Add(branch);
                        db.SaveChanges();
                    }
                    Branchs = Branchs / 2;
                }

                //Creation of the final team was not possible in the last loop.
                branch.Team = "";
                branch.SortBranch = 1;
                branch.Round = 0;

                db.Branchs.Add(branch);
                db.SaveChanges();
            }
            else
            {
                if (ModelState.IsValid)
                {
                    db.Branchs.Add(branch);
                    db.SaveChanges();
                    return RedirectToAction("Index", new { TournamentId = branch.TournamentId, currentTeam = currentTeam });
                }
            }
            return RedirectToAction("Index", "Tournament", null);
        }

        // GET: Branch/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Branch chave = db.Branchs.Find(id);
            if (chave == null)
            {
                return HttpNotFound();
            }
            
            return View(chave);
        }

        // POST: Branch/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BranchId,TournamentId,Team,Round,SortBranch")] Branch branch)
        {
            if (ModelState.IsValid)
            {
                db.Entry(branch).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", new { TournamentId = branch.TournamentId });
            }
            return View(branch);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
